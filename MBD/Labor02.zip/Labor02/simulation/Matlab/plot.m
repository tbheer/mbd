u.get('Time');

plot(u.get('Data'),i.get('Data'))